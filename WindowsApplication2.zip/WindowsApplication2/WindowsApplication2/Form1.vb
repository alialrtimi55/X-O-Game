﻿Public Class Form1

    Dim xo As String




    
    Private Sub p00_Click(sender As Object, e As EventArgs) Handles p00.Click
        If (p00.Text = "") Then
            p00.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If



    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        xo = "x"
    End Sub

    Private Sub p10_Click(sender As Object, e As EventArgs) Handles p10.Click
        If (p10.Text = "") Then
            p10.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If


    End Sub

    Private Sub p20_Click(sender As Object, e As EventArgs) Handles p20.Click
        If (p20.Text = "") Then
            p20.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If


    End Sub

    Private Sub p01_Click(sender As Object, e As EventArgs) Handles p01.Click
        If (p01.Text = "") Then
            p01.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If



    End Sub

    Private Sub p02_Click(sender As Object, e As EventArgs) Handles p02.Click
        If (p02.Text = "") Then
            p02.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If



    End Sub

    Private Sub p11_Click(sender As Object, e As EventArgs) Handles p11.Click
        If (p11.Text = "") Then
            p11.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If


    End Sub

    Private Sub p21_Click(sender As Object, e As EventArgs) Handles p21.Click
        If (p21.Text = "") Then
            p21.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If


    End Sub

    Private Sub p12_Click(sender As Object, e As EventArgs) Handles p12.Click
        If (p12.Text = "") Then
            p12.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If


    End Sub
    Public Sub newgame()
        p00.Text = ""
        p01.Text = ""
        p02.Text = ""
        p11.Text = ""
        p12.Text = ""
        p10.Text = ""
        p20.Text = ""
        p21.Text = ""
        p22.Text = ""
        xo = "x"

    End Sub
    Private Sub p22_Click(sender As Object, e As EventArgs) Handles p22.Click
        If (p22.Text = "") Then
            p22.Text = xo
            If (p00.Text = xo And p10.Text = xo And p20.Text = xo) Or (p00.Text = xo And p11.Text = xo And p22.Text = xo) Or (p02.Text = xo And p11.Text = xo And p20.Text = xo) Or (p20.Text = xo And p21.Text = xo And p22.Text = xo) Or (p00.Text = xo And p01.Text = xo And p02.Text = xo) Or (p10.Text = xo And p11.Text = xo And p12.Text = xo) Or (p01.Text = xo And p11.Text = xo And p21.Text = xo) Or (p02.Text = xo And p12.Text = xo And p22.Text = xo) Then
                MsgBox("لقد ربحت يا صاحب الـ " + "  " + xo)
                newgame()
            Else
                If (xo = "x") Then
                    xo = "o"
                Else
                    xo = "x"
                End If

            End If
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        newgame()
    End Sub
End Class
