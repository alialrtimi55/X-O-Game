﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.p00 = New System.Windows.Forms.Button()
        Me.p01 = New System.Windows.Forms.Button()
        Me.p02 = New System.Windows.Forms.Button()
        Me.p10 = New System.Windows.Forms.Button()
        Me.p11 = New System.Windows.Forms.Button()
        Me.p12 = New System.Windows.Forms.Button()
        Me.p20 = New System.Windows.Forms.Button()
        Me.p22 = New System.Windows.Forms.Button()
        Me.p21 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'p00
        '
        Me.p00.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p00.Location = New System.Drawing.Point(24, 12)
        Me.p00.Name = "p00"
        Me.p00.Size = New System.Drawing.Size(95, 81)
        Me.p00.TabIndex = 0
        Me.p00.UseVisualStyleBackColor = True
        '
        'p01
        '
        Me.p01.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p01.Location = New System.Drawing.Point(128, 12)
        Me.p01.Name = "p01"
        Me.p01.Size = New System.Drawing.Size(95, 81)
        Me.p01.TabIndex = 1
        Me.p01.UseVisualStyleBackColor = True
        '
        'p02
        '
        Me.p02.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p02.Location = New System.Drawing.Point(233, 12)
        Me.p02.Name = "p02"
        Me.p02.Size = New System.Drawing.Size(95, 81)
        Me.p02.TabIndex = 2
        Me.p02.UseVisualStyleBackColor = True
        '
        'p10
        '
        Me.p10.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p10.Location = New System.Drawing.Point(24, 99)
        Me.p10.Name = "p10"
        Me.p10.Size = New System.Drawing.Size(95, 81)
        Me.p10.TabIndex = 3
        Me.p10.UseVisualStyleBackColor = True
        '
        'p11
        '
        Me.p11.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p11.Location = New System.Drawing.Point(128, 99)
        Me.p11.Name = "p11"
        Me.p11.Size = New System.Drawing.Size(95, 81)
        Me.p11.TabIndex = 4
        Me.p11.UseVisualStyleBackColor = True
        '
        'p12
        '
        Me.p12.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p12.Location = New System.Drawing.Point(233, 99)
        Me.p12.Name = "p12"
        Me.p12.Size = New System.Drawing.Size(95, 81)
        Me.p12.TabIndex = 5
        Me.p12.UseVisualStyleBackColor = True
        '
        'p20
        '
        Me.p20.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p20.Location = New System.Drawing.Point(24, 186)
        Me.p20.Name = "p20"
        Me.p20.Size = New System.Drawing.Size(95, 81)
        Me.p20.TabIndex = 6
        Me.p20.UseVisualStyleBackColor = True
        '
        'p22
        '
        Me.p22.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p22.Location = New System.Drawing.Point(233, 186)
        Me.p22.Name = "p22"
        Me.p22.Size = New System.Drawing.Size(95, 81)
        Me.p22.TabIndex = 7
        Me.p22.UseVisualStyleBackColor = True
        '
        'p21
        '
        Me.p21.Font = New System.Drawing.Font("Tahoma", 30.0!)
        Me.p21.Location = New System.Drawing.Point(128, 186)
        Me.p21.Name = "p21"
        Me.p21.Size = New System.Drawing.Size(95, 81)
        Me.p21.TabIndex = 8
        Me.p21.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.Chartreuse
        Me.Button10.Location = New System.Drawing.Point(24, 273)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(304, 30)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "اعادة اللعب"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(341, 315)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.p21)
        Me.Controls.Add(Me.p22)
        Me.Controls.Add(Me.p20)
        Me.Controls.Add(Me.p12)
        Me.Controls.Add(Me.p11)
        Me.Controls.Add(Me.p10)
        Me.Controls.Add(Me.p02)
        Me.Controls.Add(Me.p01)
        Me.Controls.Add(Me.p00)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents p00 As System.Windows.Forms.Button
    Friend WithEvents p01 As System.Windows.Forms.Button
    Friend WithEvents p02 As System.Windows.Forms.Button
    Friend WithEvents p11 As System.Windows.Forms.Button
    Friend WithEvents p12 As System.Windows.Forms.Button
    Friend WithEvents p20 As System.Windows.Forms.Button
    Friend WithEvents p22 As System.Windows.Forms.Button
    Friend WithEvents p21 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents p10 As System.Windows.Forms.Button

End Class
